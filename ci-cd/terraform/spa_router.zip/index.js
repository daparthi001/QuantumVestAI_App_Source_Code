// SPA router for CloudFront
exports.handler = (event, context, callback) => {
  const request = event.Records[0].cf.request;
  const uri = request.uri;
        
  // Check if the request is for a file with an extension
  if (uri.includes('.')) {
    callback(null, request);
    return;
  }
        
  // Otherwise, rewrite to index.html
  request.uri = '/index.html';
  callback(null, request);
};
