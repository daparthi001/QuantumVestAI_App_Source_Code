from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/admin", tags=["admin"])

# Dummy in-memory admin data store
admins = {
    "admin1": {"name": "Alice", "role": "superuser"},
    "admin2": {"name": "Bob", "role": "moderator"}
}

class Admin(BaseModel):
    username: str
    name: str
    role: str

@router.get("/health")
def health_check():
    return {"status": "Admin API is running"}

@router.get("/list")
def list_admins():
    return admins

@router.get("/{username}")
def get_admin(username: str):
    if username not in admins:
        raise HTTPException(status_code=404, detail="Admin not found")
    return admins[username]

@router.post("/add")
def add_admin(admin: Admin):
    if admin.username in admins:
        raise HTTPException(status_code=400, detail="Admin already exists")
    admins[admin.username] = admin.dict()
    return {"message": f"Admin '{admin.username}' added successfully."}

@router.delete("/remove/{username}")
def remove_admin(username: str):
    if username not in admins:
        raise HTTPException(status_code=404, detail="Admin not found")
    del admins[username]
    return {"message": f"Admin '{username}' removed successfully."}